package com.example.imc

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.imc.IMCStorage
import com.example.imc.HistoryActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etWeight = findViewById<EditText>(R.id.etWeight)
        val etHeight = findViewById<EditText>(R.id.etHeight)
        val btnCalculate = findViewById<Button>(R.id.btnCalculate)
        val btnHistory = findViewById<Button>(R.id.btnHistory)
        val tvResult = findViewById<TextView>(R.id.tvResult)

        btnCalculate.setOnClickListener {
            val weight = etWeight.text.toString().toFloatOrNull()
            val height = etHeight.text.toString().toFloatOrNull()

            if (weight != null && height != null && height > 0) {
                val imc = weight / (height * height)
                val classification = classifyIMC(imc)
                val result = "Peso: $weight, Altura: $height, IMC: %.2f\nClassificação: %s".format(imc, classification)

                tvResult.text = result
                IMCStorage.addEntry(result)
            } else {
                Toast.makeText(this, "Insira valores válidos", Toast.LENGTH_SHORT).show()
            }
        }

        btnHistory.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
    }

    private fun classifyIMC(imc: Float): String {
        return when {
            imc < 18.5 -> "Magreza"
            imc < 25 -> "Peso normal"
            imc < 30 -> "Sobrepeso"
            imc < 35 -> "Obesidade grau I"
            imc < 40 -> "Obesidade grau II"
            else -> "Obesidade grau III(Mórbida)"
        }
    }
}
