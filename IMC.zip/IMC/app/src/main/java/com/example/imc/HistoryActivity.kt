package com.example.imc

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.imc.IMCAdapter
import com.example.imc.IMCStorage

class HistoryActivity : AppCompatActivity() {
    private lateinit var adapter: IMCAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerViewIMC)
        val btnClear = findViewById<Button>(R.id.btnClear)

        adapter = IMCAdapter(IMCStorage.history)
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        btnClear.setOnClickListener {
            IMCStorage.clear()
            adapter.notifyDataSetChanged()
            Toast.makeText(this, "Histórico limpo", Toast.LENGTH_SHORT).show()
        }
    }
}
