package com.example.imc

object IMCStorage {
    val history = mutableListOf<String>()

    fun addEntry(entry: String) {
        history.add(0, entry)
    }

    fun clear() {
        history.clear()
    }
}
